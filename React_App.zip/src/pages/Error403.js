import React from "react";

export default function Error403(){
    return(
        <div>
            <h1>
                Error 403: Forbidden
            </h1>
        </div>
    )
}