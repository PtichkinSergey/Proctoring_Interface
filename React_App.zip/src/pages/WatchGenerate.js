import React from "react";

export default function WatchGenerate(props) {
    // let access = JSON.parse(localStorage.getItem('user'));
    // if (access !== null) {
    //     return <div/>;
    // } else {
    //     return (
    //         <div>
    //             <h1>Sorry.</h1>
    //             <h2>You dont have access to this page.</h2>
    //             <h2>You need to log in first.</h2>
    //         </div>
    //     );
    // }
    return <div/>;
}
